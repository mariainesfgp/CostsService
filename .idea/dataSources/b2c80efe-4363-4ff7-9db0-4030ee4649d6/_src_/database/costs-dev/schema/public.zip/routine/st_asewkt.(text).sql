create function st_asewkt(text) returns text
IMMUTABLE
LANGUAGE SQL
AS $$
SELECT public.ST_AsEWKT($1::public.geometry);
$$;
