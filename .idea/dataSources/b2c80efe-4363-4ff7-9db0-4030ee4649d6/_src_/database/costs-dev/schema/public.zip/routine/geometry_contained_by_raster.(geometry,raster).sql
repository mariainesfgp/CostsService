create function geometry_contained_by_raster(geometry, raster) returns boolean
IMMUTABLE
LANGUAGE SQL
AS $$
select $1 OPERATOR(public.@) $2::geometry
$$;
