create function st_asgeojson(geog geography, maxdecimaldigits integer DEFAULT 15, options integer DEFAULT 0) returns text
IMMUTABLE
LANGUAGE SQL
AS $$
SELECT public._ST_AsGeoJson(1, $1, $2, $3);
$$;
