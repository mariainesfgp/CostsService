create function geometry_raster_overlap(geometry, raster) returns boolean
IMMUTABLE
LANGUAGE SQL
AS $$
select $1 OPERATOR(public.&&) $2::geometry
$$;
