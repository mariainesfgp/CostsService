create function "_st_distancetree"(geography, geography) returns double precision
IMMUTABLE
LANGUAGE SQL
AS $$
SELECT public._ST_DistanceTree($1, $2, 0.0, true)
$$;
