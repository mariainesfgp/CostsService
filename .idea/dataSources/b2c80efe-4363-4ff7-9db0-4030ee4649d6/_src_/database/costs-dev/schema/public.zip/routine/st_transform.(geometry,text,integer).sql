create function st_transform(geom geometry, from_proj text, to_srid integer) returns geometry
IMMUTABLE
LANGUAGE SQL
AS $$
SELECT public.postgis_transform_geometry($1, $2, proj4text, $3)
FROM spatial_ref_sys WHERE srid=$3;
$$;
