create function st_asjpeg(rast raster, nband integer, quality integer) returns bytea
IMMUTABLE
LANGUAGE SQL
AS $$
SELECT public.st_asjpeg($1, ARRAY[$2], $3)
$$;
