create function geometry_raster_contain(geometry, raster) returns boolean
IMMUTABLE
LANGUAGE SQL
AS $$
select $1 OPERATOR(public.~) $2::geometry
$$;
