create function raster_geometry_overlap(raster, geometry) returns boolean
IMMUTABLE
LANGUAGE SQL
AS $$
select $1::geometry OPERATOR(public.&&) $2
$$;
