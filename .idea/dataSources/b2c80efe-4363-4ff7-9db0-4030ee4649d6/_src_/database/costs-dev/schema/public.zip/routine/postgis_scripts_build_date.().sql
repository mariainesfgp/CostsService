create function postgis_scripts_build_date() returns text
IMMUTABLE
LANGUAGE SQL
AS $$
SELECT '2017-10-17 19:50:14'::text AS version
$$;
