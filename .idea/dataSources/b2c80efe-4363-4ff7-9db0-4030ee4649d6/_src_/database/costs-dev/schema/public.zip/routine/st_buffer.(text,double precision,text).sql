create function st_buffer(text, double precision, text) returns geometry
IMMUTABLE
LANGUAGE SQL
AS $$
SELECT ST_Buffer($1::public.geometry, $2, $3);
$$;
