create function st_pixelaspoints(rast raster, band integer DEFAULT 1, exclude_nodata_value boolean DEFAULT true, OUT geom geometry, OUT val double precision, OUT x integer, OUT y integer) returns SETOF record
IMMUTABLE
LANGUAGE SQL
AS $$
SELECT public.ST_PointN(  public.ST_ExteriorRing(geom), 1), val, x, y FROM public._ST_pixelaspolygons($1, $2, NULL, NULL, $3)
$$;
