create function st_worldtorastercoordx(rast raster, xw double precision) returns integer
IMMUTABLE
LANGUAGE SQL
AS $$
SELECT columnx FROM public._ST_worldtorastercoord($1, $2, NULL)
$$;
