create function st_valuecount(rast raster, nband integer, searchvalues double precision[], roundto double precision DEFAULT 0, OUT value double precision, OUT count integer) returns SETOF record
IMMUTABLE
LANGUAGE SQL
AS $$
SELECT value, count FROM public._ST_valuecount($1, $2, TRUE, $3, $4)
$$;
