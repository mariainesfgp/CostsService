create function "_st_asgeojson"(integer, geometry, integer, integer) returns text
IMMUTABLE
LANGUAGE SQL
AS $$
SELECT public.ST_AsGeoJson($2::public.geometry, $3::int4, $4::int4);
$$;
